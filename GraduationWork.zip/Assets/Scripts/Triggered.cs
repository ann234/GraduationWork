﻿using UnityEngine;
using System.Collections;

public class Door : Door_switch {
    
}
