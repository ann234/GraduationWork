﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Rope : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

    public void OnColliderEnter(Collision cols)
    {

    }
}
